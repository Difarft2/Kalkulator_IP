<!DOCTYPE html>
<html>

<head>
    <title>IP Calculator</title>
    <style>
    body {
        font-family: Arial;
        margin: 20px;
    }

    input {
        padding: 5px;
        margin: 5px;
    }

    .output {
        margin-top: 20px;
    }

    .error {
        color: red;
    }
    </style>
</head>

<body>
    <h2>IP Calculator</h2>
    @if(session('error'))
    <div class="error">{{ session('error') }}</div>
    @endif
    <form method="POST" action="{{ route('calculate') }}">
        @csrf
        Address: <input type="text" name="ip" value="{{ old('ip', $ip ?? '') }}" required>
        /
        <input type="number" name="cidr" value="{{ old('cidr', $cidr ?? '24') }}" min="1" max="32" required>
        <button type="submit">Calculate</button>
    </form>

    @isset($netmask)
    <div class="output">
        <p><strong>Address:</strong> {{ $ip }}</p>
        <p><strong>Netmask:</strong> {{ $netmask }} = {{ $cidr }}</p>
        <p><strong>Wildcard:</strong> {{ $wildcard }}</p>
        <p><strong>Network:</strong> {{ $network }}/{{ $cidr }}</p>
        <p><strong>Broadcast:</strong> {{ $broadcast }}</p>
        <p><strong>HostMin:</strong> {{ $hostMin }}</p>
        <p><strong>HostMax:</strong> {{ $hostMax }}</p>
        <p><strong>Hosts/Net:</strong> {{ $hosts }}</p>
    </div>
    @endisset
</body>

</html>