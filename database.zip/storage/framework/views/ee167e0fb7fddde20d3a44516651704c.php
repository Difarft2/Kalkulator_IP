<!DOCTYPE html>
<html>

<head>
    <title>IP Calculator</title>
    <style>
    body {
        font-family: Arial;
        margin: 20px;
    }

    input {
        padding: 5px;
        margin: 5px;
    }

    .output {
        margin-top: 20px;
    }

    .error {
        color: red;
    }
    </style>
</head>

<body>
    <h2>IP Calculator</h2>
    <?php if(session('error')): ?>
    <div class="error"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('calculate')); ?>">
        <?php echo csrf_field(); ?>
        Address: <input type="text" name="ip" value="<?php echo e(old('ip', $ip ?? '')); ?>" required>
        /
        <input type="number" name="cidr" value="<?php echo e(old('cidr', $cidr ?? '24')); ?>" min="1" max="32" required>
        <button type="submit">Calculate</button>
    </form>

    <?php if(isset($netmask)): ?>
    <div class="output">
        <p><strong>Address:</strong> <?php echo e($ip); ?></p>
        <p><strong>Netmask:</strong> <?php echo e($netmask); ?> = <?php echo e($cidr); ?></p>
        <p><strong>Wildcard:</strong> <?php echo e($wildcard); ?></p>
        <p><strong>Network:</strong> <?php echo e($network); ?>/<?php echo e($cidr); ?></p>
        <p><strong>Broadcast:</strong> <?php echo e($broadcast); ?></p>
        <p><strong>HostMin:</strong> <?php echo e($hostMin); ?></p>
        <p><strong>HostMax:</strong> <?php echo e($hostMax); ?></p>
        <p><strong>Hosts/Net:</strong> <?php echo e($hosts); ?></p>
    </div>
    <?php endif; ?>
</body>

</html><?php /**PATH D:\Web Dev\kalkulatorIP\resources\views/kalkulator.blade.php ENDPATH**/ ?>